SQR Sender — Screen QR Transfer (Zero-Install)
==============================================

Requirements:
  - Python 3.6+
  - tkinter (included with most Python installations)

Usage (Linux/macOS):
  ./send.sh <file.txt>

Usage (Windows):
  send.bat <file.txt>

Options:
  --interval 1.2          Seconds per QR frame
  --error-correction M    QR error correction: L/M/Q/H
  --max-payload 1200      Max chars per QR payload
  --output-dir <dir>      Save PPM frames (debug)
  --renderer terminal     Use terminal instead of fullscreen window
  --no-player             Only generate frames, don't display

All dependencies are bundled in sqr/vendor/. No pip install needed.
